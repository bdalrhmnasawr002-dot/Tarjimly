package com.tarjimly.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.Gravity
import android.widget.*
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class MainActivity : Activity() {
    private val pickPdf = 41
    private var selectedUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var translateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 40, 28, 24)
            setBackgroundColor(Color.rgb(250, 250, 250))
        }
        root.addView(TextView(this).apply {
            text = "ترجم لي"; textSize = 30f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(35, 70, 110))
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "ترجمة ملفات PDF من الإنجليزية إلى العربية"
            textSize = 17f; gravity = Gravity.CENTER; setPadding(0, 14, 0, 30)
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "اختيار ملف PDF"; textSize = 18f
            setOnClickListener { openPicker() }
        }, LinearLayout.LayoutParams(-1, -2))
        translateButton = Button(this).apply {
            text = "ترجمة الملف وإنشاء PDF"; textSize = 18f; isEnabled = false
            setOnClickListener { startTranslation() }
        }
        root.addView(translateButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })
        status = TextView(this).apply {
            text = "اختاري ملف PDF للبدء"; textSize = 16f
            gravity = Gravity.CENTER; setPadding(0, 24, 0, 0)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun openPicker() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
        }, pickPdf)
    }

    @Deprecated("Supported for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickPdf && resultCode == RESULT_OK) {
            selectedUri = data?.data
            translateButton.isEnabled = selectedUri != null
            status.text = if (selectedUri != null) "تم اختيار الملف. اضغطي زر الترجمة." else "لم يتم اختيار ملف."
        }
    }

    private fun startTranslation() {
        val uri = selectedUri ?: return
        translateButton.isEnabled = false
        status.text = "جارٍ تجهيز الملف..."
        Thread {
            var renderer: PdfRenderer? = null
            var fd: ParcelFileDescriptor? = null
            var translator: Translator? = null
            try {
                val inputFile = File(cacheDir, "input.pdf")
                contentResolver.openInputStream(uri).use { input ->
                    input ?: throw Exception("تعذر قراءة الملف")
                    inputFile.outputStream().use { output -> input.copyTo(output) }
                }
                fd = ParcelFileDescriptor.open(inputFile, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(fd)
                translator = Translation.getClient(TranslatorOptions.Builder()
                    .setSourceLanguage(com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH)
                    .setTargetLanguage(com.google.mlkit.nl.translate.TranslateLanguage.ARABIC).build())
                val downloadLatch = CountDownLatch(1)
                val downloadError = AtomicReference<Exception?>()
                translator.downloadModelIfNeeded()
                    .addOnSuccessListener { downloadLatch.countDown() }
                    .addOnFailureListener { downloadError.set(it); downloadLatch.countDown() }
                runOnUiThread { status.text = "جارٍ تجهيز نموذج الترجمة..." }
                if (!downloadLatch.await(180, TimeUnit.SECONDS)) throw Exception("انتهت مهلة تنزيل نموذج الترجمة")
                downloadError.get()?.let { throw it }
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val pages = mutableListOf<List<Pair<String, String>>>()
                for (i in 0 until renderer.pageCount) {
                    runOnUiThread { status.text = "معالجة الصفحة ${i + 1} من ${renderer!!.pageCount}..." }
                    val page = renderer.openPage(i)
                    val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                    val matrix = Matrix().apply { postScale(2f, 2f) }
                    page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    val latch = CountDownLatch(1)
                    val textResult = AtomicReference<String>()
                    val textError = AtomicReference<Exception?>()
                    recognizer.process(InputImage.fromBitmap(bitmap, 0))
                        .addOnSuccessListener { textResult.set(it.text); latch.countDown() }
                        .addOnFailureListener { textError.set(it); latch.countDown() }
                    bitmap.recycle()
                    if (!latch.await(120, TimeUnit.SECONDS)) throw Exception("انتهت مهلة قراءة الصفحة")
                    textError.get()?.let { throw it }
                    val lines = textResult.get().orEmpty().split("\n").map { it.trim() }.filter { it.isNotBlank() }
                    val translated = mutableListOf<Pair<String, String>>()
                    for (line in lines) translated.add(line to translateSync(translator, line))
                    pages.add(translated)
                }
                recognizer.close()
                renderer.close(); renderer = null
                fd.close(); fd = null
                translator.close(); translator = null
                val output = File(getExternalFilesDir(null), "Tarjimly_Arabic.pdf")
                createPdf(pages, output)
                runOnUiThread {
                    status.text = "اكتملت الترجمة. حُفظ الملف داخل مجلد التطبيق."
                    translateButton.isEnabled = true
                    AlertDialog.Builder(this).setTitle("اكتمل إنشاء الملف")
                        .setMessage("تم حفظ الملف باسم Tarjimly_Arabic.pdf في مساحة ملفات التطبيق. هذا إصدار أولي وقد لا يحافظ على تنسيق الملف الأصلي.")
                        .setPositiveButton("حسنًا", null).show()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "حدث خطأ: ${e.localizedMessage ?: "حاولي مرة أخرى"}"; translateButton.isEnabled = true }
            } finally {
                try { renderer?.close() } catch (_: Exception) {}
                try { fd?.close() } catch (_: Exception) {}
                try { translator?.close() } catch (_: Exception) {}
            }
        }.start()
    }

    private fun translateSync(translator: Translator, text: String): String {
        val latch = CountDownLatch(1)
        val result = AtomicReference<String>()
        val error = AtomicReference<Exception?>()
        translator.translate(text).addOnSuccessListener { result.set(it); latch.countDown() }
            .addOnFailureListener { error.set(it); latch.countDown() }
        if (!latch.await(90, TimeUnit.SECONDS)) throw Exception("انتهت مهلة الترجمة")
        error.get()?.let { throw it }
        return result.get() ?: ""
    }

    private fun createPdf(pages: List<List<Pair<String, String>>>, output: File) {
        val doc = PdfDocument()
        val w = 595; val h = 842; val margin = 42f
        val enPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 15f; color = Color.BLACK }
        val arPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; color = Color.rgb(20, 65, 110) }
        var num = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, num).create())
        var canvas = page.canvas
        canvas.drawColor(Color.WHITE)
        var y = margin
        fun nextPage() {
            doc.finishPage(page); num++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, num).create())
            canvas = page.canvas; canvas.drawColor(Color.WHITE); y = margin
        }
        for (items in pages) {
            for ((en, ar) in items) {
                val enLayout = StaticLayout.Builder.obtain(en, 0, en.length, enPaint, (w - 2 * margin).toInt())
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.LTR).build()
                val arLayout = StaticLayout.Builder.obtain(ar, 0, ar.length, arPaint, (w - 2 * margin).toInt())
                    .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).build()
                val required = enLayout.height + arLayout.height + 24f
                if (y + required > h - margin) nextPage()
                canvas.save(); canvas.translate(margin, y); enLayout.draw(canvas); canvas.restore()
                y += enLayout.height + 5f
                canvas.save(); canvas.translate(margin, y); arLayout.draw(canvas); canvas.restore()
                y += arLayout.height + 18f
                canvas.drawLine(margin, y - 8, w - margin, y - 8, Paint().apply { color = Color.LTGRAY })
            }
            y += 10f
        }
        doc.finishPage(page)
        output.parentFile?.mkdirs()
        FileOutputStream(output).use { doc.writeTo(it) }
        doc.close()
    }
}
